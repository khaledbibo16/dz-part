const express=require("express");
const path=require("path");
const multer=require("multer");
const bcrypt = require("bcryptjs");
const fs=require("fs");
const db=require("./database");
const app=express();
const PORT=3000;

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));

const uploadDir=path.join(__dirname,"public","uploads");
if(!fs.existsSync(uploadDir))fs.mkdirSync(uploadDir,{recursive:true});

const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,uploadDir),
 filename:(req,file,cb)=>cb(null,Date.now()+"-"+Math.round(Math.random()*1e9)+path.extname(file.originalname).toLowerCase())
});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>file.mimetype.startsWith("image/")?cb(null,true):cb(new Error("يسمح برفع الصور فقط"))});

const productSelect=`
 SELECT products.id,products.title,products.description,products.price,products.user_id,
 products.category,products.wilaya,products.image,users.name AS seller,users.email AS seller_email,
 users.phone AS sellerPhone
 FROM products LEFT JOIN users ON products.user_id=users.id`;

app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.post("/signup",(req,res)=>{
 const {name,email,password,phone}=req.body;
 if(!name||!email||!password||!phone)return res.status(400).json({message:"جميع المعلومات مطلوبة"});
 db.query("SELECT id FROM users WHERE email=?",[email],(err,rows)=>{
  if(err)return res.status(500).json({message:"حدث خطأ في قاعدة البيانات",error:err.message});
  if(rows.length)return res.status(400).json({message:"البريد الإلكتروني موجود مسبقًا"});
  const hashedPassword=bcrypt.hashSync(password,10);
  db.query("INSERT INTO users(name,email,password,phone) VALUES(?,?,?,?)",[name,email,hashedPassword,phone],(err,r)=>{
   if(err)return res.status(500).json({message:"فشل إنشاء الحساب",error:err.message});
   res.json({message:"تم إنشاء الحساب بنجاح",user:{id:r.insertId,name,email,phone}});
  });
 });
});

app.post("/login",(req,res)=>{
 const {email,password}=req.body;
 if(!email||!password)return res.status(400).json({message:"البريد الإلكتروني وكلمة المرور مطلوبان"});
 db.query("SELECT id,name,email,password,phone FROM users WHERE email=?",[email],(err,rows)=>{
  if(err)return res.status(500).json({message:"حدث خطأ في قاعدة البيانات",error:err.message});
  if(!rows.length)return res.status(401).json({message:"البريد الإلكتروني غير موجود"});
  const u=rows[0];
  if(u.password.startsWith("$2b$") || u.password.startsWith("$2a$") || u.password.startsWith("$2y$")){
   if(!bcrypt.compareSync(password,u.password))return res.status(401).json({message:"كلمة المرور غير صحيحة"});
  }else{
   if(u.password!==password)return res.status(401).json({message:"كلمة المرور غير صحيحة"});
   const hashedPassword=bcrypt.hashSync(password,10);
   db.query("UPDATE users SET password=? WHERE id=?",[hashedPassword,u.id],(updateErr)=>{
    if(updateErr)return res.status(500).json({message:"تم الدخول لكن فشل تحديث حماية كلمة المرور"});
   });
  }
  res.json({message:"تم تسجيل الدخول بنجاح",user:{id:u.id,name:u.name,email:u.email,phone:u.phone}});
 });
});

app.get("/products",(req,res)=>{
 db.query(productSelect+" ORDER BY products.id DESC",(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء جلب الإعلانات",error:err.message}):res.json(rows));
});
app.get("/products/user/:userId",(req,res)=>{
 db.query(productSelect+" WHERE products.user_id=? ORDER BY products.id DESC",[req.params.userId],(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء جلب إعلاناتك",error:err.message}):res.json(rows));
});
app.get("/my-products/:user_id",(req,res)=>{
 db.query(productSelect+" WHERE products.user_id=? ORDER BY products.id DESC",[req.params.user_id],(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء جلب إعلاناتك",error:err.message}):res.json(rows));
});
app.get("/products/search",(req,res)=>{
 const q=String(req.query.q||"").trim();if(!q)return res.status(400).json({message:"اكتب كلمة البحث"});
 const s="%"+q+"%";
 db.query(productSelect+" WHERE products.title LIKE ? OR products.description LIKE ? OR products.category LIKE ? OR products.wilaya LIKE ? ORDER BY products.id DESC",[s,s,s,s],(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء البحث",error:err.message}):res.json(rows));
});

const cats=["هواتف","إعلام آلي","سيارات","عقارات","ملابس","رياضة"];
app.get("/products/category/:category",(req,res)=>{
 const category=decodeURIComponent(req.params.category);
 if(!cats.includes(category))return res.status(400).json({message:"القسم غير معروف"});
 db.query(productSelect+" WHERE products.category=? ORDER BY products.id DESC",[category],(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء جلب القسم",error:err.message}):res.json(rows));
});
["cars","computers","realestate","clothes","phones","sports"].forEach((slug)=>{
 const map={cars:"سيارات",computers:"إعلام آلي",realestate:"عقارات",clothes:"ملابس",phones:"هواتف",sports:"رياضة"};
 app.get("/products/category/"+slug,(req,res)=>db.query(productSelect+" WHERE products.category=? ORDER BY products.id DESC",[map[slug]],(err,rows)=>err?res.status(500).json({message:"حدث خطأ أثناء جلب القسم",error:err.message}):res.json(rows)));
});

app.get("/products/:id",(req,res)=>{
 db.query(productSelect+" WHERE products.id=?",[req.params.id],(err,rows)=>{
  if(err)return res.status(500).json({message:"حدث خطأ",error:err.message});
  if(!rows.length)return res.status(404).json({message:"الإعلان غير موجود"});
  res.json(rows[0]);
 });
});

app.post("/products",upload.single("image"),(req,res)=>{
 const {title,description,price,user_id,category,wilaya}=req.body;
 if(!title||!description||!price||!user_id||!category||!wilaya)return res.status(400).json({message:"جميع معلومات الإعلان مطلوبة"});
 const image=req.file?"/uploads/"+req.file.filename:null;
 db.query("INSERT INTO products(title,description,price,user_id,category,wilaya,image) VALUES(?,?,?,?,?,?,?)",[title,description,price,user_id,category,wilaya,image],(err,r)=>{
  if(err)return res.status(500).json({message:"فشل إضافة الإعلان",error:err.message});
  res.json({message:"تم إضافة الإعلان بنجاح",product:{id:r.insertId,title,description,price,user_id,category,wilaya,image}});
 });
});

app.put("/products/:id",upload.single("image"),(req,res)=>{
 const id=req.params.id,{title,description,price,user_id,category,wilaya}=req.body;
 if(!title||!description||!price||!user_id||!category||!wilaya)return res.status(400).json({message:"جميع معلومات الإعلان مطلوبة"});
 db.query("SELECT user_id,image FROM products WHERE id=?",[id],(err,rows)=>{
  if(err)return res.status(500).json({message:"حدث خطأ في قاعدة البيانات",error:err.message});
  if(!rows.length)return res.status(404).json({message:"الإعلان غير موجود"});
  if(String(rows[0].user_id)!==String(user_id))return res.status(403).json({message:"لا يمكنك تعديل هذا الإعلان"});
  const image=req.file?"/uploads/"+req.file.filename:rows[0].image;
  db.query("UPDATE products SET title=?,description=?,price=?,category=?,wilaya=?,image=? WHERE id=?",[title,description,price,category,wilaya,image,id],err=>{
   if(err)return res.status(500).json({message:"فشل تعديل الإعلان",error:err.message});
   res.json({message:"تم تعديل الإعلان بنجاح"});
  });
 });
});

app.delete("/products/:id",(req,res)=>{
 const id=req.params.id,user_id=req.body.user_id;
 if(!user_id)return res.status(400).json({message:"معرف المستخدم مطلوب"});
 db.query("SELECT user_id,image FROM products WHERE id=?",[id],(err,rows)=>{
  if(err)return res.status(500).json({message:"حدث خطأ في قاعدة البيانات",error:err.message});
  if(!rows.length)return res.status(404).json({message:"الإعلان غير موجود"});
  if(String(rows[0].user_id)!==String(user_id))return res.status(403).json({message:"لا يمكنك حذف هذا الإعلان"});
  const image=rows[0].image;
  db.query("DELETE FROM products WHERE id=?",[id],err=>{
   if(err)return res.status(500).json({message:"فشل حذف الإعلان",error:err.message});
   if(image&&image.startsWith("/uploads/")){const fp=path.join(__dirname,"public",image);fs.unlink(fp,()=>{});}
   res.json({message:"تم حذف الإعلان بنجاح"});
  });
 });
});

app.use((err,req,res,next)=>{console.error(err);res.status(400).json({message:err.message||"حدث خطأ في السيرفر"})});
app.listen(PORT,()=>{console.log(`Server running on port ${PORT}`);console.log("سويقة تعمل بنجاح 🚀")});
